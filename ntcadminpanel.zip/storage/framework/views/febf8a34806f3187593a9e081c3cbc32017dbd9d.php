

<?php $__env->startSection('title', 'Permissions'); ?>

<?php $__env->startSection('content'); ?>
<section class="content mt-4 home">
		<div class="container-fluid">
			<div class="row clearfix">
				<div class="col-sm-12">
<h1>Permissions Page</h1>

                </div>
            </div>
        </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\test-task\login-admin\ghulam-ali-app\resources\views/web/permissions.blade.php ENDPATH**/ ?>
<meta charset="UTF-8">
	<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="Valex – Bootstrap5  Admin & Dashboard Template">
	<meta name="author" content="Spruko Technologies Private Limited">
	<meta name="keywords"
		content="admin, dashboard, backend, flat, jquery, Ui, crm, admin template, responsive , bootstrap, clean, scss, modern, minimal, panel"><?php /**PATH /home/netrootstechco/ntcadmin.netrootstech.co.uk/resources/views/layouts/meta_tags.blade.php ENDPATH**/ ?>
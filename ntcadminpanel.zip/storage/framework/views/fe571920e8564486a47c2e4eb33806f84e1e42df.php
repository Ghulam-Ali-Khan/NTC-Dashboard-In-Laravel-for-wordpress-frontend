<!DOCTYPE html>
<html>

<head>
    <!-- Meta data -->
    <?php echo $__env->make('layouts.meta_tags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Title -->
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('layouts.css_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="theme-blush">



    <?php echo $__env->yieldContent('content'); ?>;
   <!-- SideBar -->
   <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- End Sidebar -->
    
        <!-- Footer opened -->
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Footer closed -->
    </section>

    <!-- Navbar -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Navbar End -->

    <!-- Js files -->
    <?php echo $__env->make('layouts.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Js files end -->
</body>

</html><?php /**PATH C:\xampp\htdocs\test-task\login-admin\ghulam-ali-app\resources\views/layouts/main.blade.php ENDPATH**/ ?>
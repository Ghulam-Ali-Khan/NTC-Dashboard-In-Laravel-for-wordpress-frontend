<link rel="icon" href="<?php echo e(asset('public/assets/images/favicon.png')); ?>" type="image/x-icon">
	<link href="<?php echo e(asset('assets/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" />
	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">
	<link href="<?php echo e(asset('assets/plugins/iconfonts/icons.css')); ?>" rel="stylesheet" />
	<!-- Custom Css -->
	<link href="<?php echo e(asset('assets/css/main.css')); ?>" rel="stylesheet">
	<!---Internal  Prism css-->
	<link href="<?php echo e(asset('assets/plugins/prism/prism.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('assets/plugins/treeview-prism/prism.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('assets/plugins/treeview-prism/prism-treeview.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('assets/css/themes/all-themes.css')); ?>" rel="stylesheet" />
	<link rel="stylesheet" href="//cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
	<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Itim&display=swap" rel="stylesheet"><?php /**PATH C:\xampp\htdocs\test-task\login-admin\ghulam-ali-app\resources\views/layouts/css_links.blade.php ENDPATH**/ ?>
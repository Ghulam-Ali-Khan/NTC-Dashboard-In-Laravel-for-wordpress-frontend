<div class="main-footer ht-40">
			<div class="pd-t-0-f ht-100p">
				<span>Copyright &copy; 2023 <a href="javascript:void(0);">NTC</a>. Designed by <a
						href="https://www.netrootstech.com/">Netroots</a> All rights reserved.</span>
			</div>
		</div><?php /**PATH /home/netrootstechco/ntcadmin.netrootstech.co.uk/resources/views/layouts/footer.blade.php ENDPATH**/ ?>
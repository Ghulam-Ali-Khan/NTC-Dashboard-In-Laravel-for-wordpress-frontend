 <!-- Sidebarover lay -->
 <div class="sidebar-overlay" data-toggle="sidebar"></div>
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="admin-image"> <img src="assets/images/NTC-Logo.jpg" alt=""> </div>
            <!-- Menu -->
            <div class="menu main-sidebar">
                <ul class="list" id="documenter_nav">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo route('home'); ?>"><i class="fe fe-airplay sidemenu-icon"></i><span class="sidemenu-label">Home</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo route('tenders'); ?>"><i class="fe fe-folder sidemenu-icon"></i><span class="sidemenu-label">Tenders</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo route('policies'); ?>"><i class="fe fe-layout sidemenu-icon"></i><span class="sidemenu-label">Policies</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo route('apply-downloads'); ?>"><i class="fe fe-layout sidemenu-icon"></i><span class="sidemenu-label">Apply & Downloads</span></a>
                    </li>
                  
                </ul>
            </div>
            <!-- #Menu -->
        </aside>
        <!-- #END# Left Sidebar -->
    </section><?php /**PATH /home/netrootstechco/ntcadmin.netrootstech.co.uk/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>